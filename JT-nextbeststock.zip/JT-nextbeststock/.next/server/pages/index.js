/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(function() {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./components/DateTime/index.js":
/*!**************************************!*\
  !*** ./components/DateTime/index.js ***!
  \**************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n\nvar _jsxFileName = \"/Users/jasothomas/Documents/Projects/SA-2.0/JT-nextbeststock/components/DateTime/index.js\";\n\nvar datetime = () => {\n  var showdate = new Date();\n  var dt = showdate.toDateString();\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"screenLeft\", {\n      children: dt\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 6,\n      columnNumber: 13\n    }, undefined)\n  }, void 0, false, {\n    fileName: _jsxFileName,\n    lineNumber: 5,\n    columnNumber: 9\n  }, undefined);\n};\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (datetime);//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0YmVzdHN0b2NrLy4vY29tcG9uZW50cy9EYXRlVGltZS9pbmRleC5qcz8wNmVkIl0sIm5hbWVzIjpbImRhdGV0aW1lIiwic2hvd2RhdGUiLCJEYXRlIiwiZHQiLCJ0b0RhdGVTdHJpbmciXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBLElBQUlBLFFBQVEsR0FBRyxNQUFLO0FBQ2hCLE1BQUlDLFFBQVEsR0FBQyxJQUFJQyxJQUFKLEVBQWI7QUFDQSxNQUFJQyxFQUFFLEdBQUNGLFFBQVEsQ0FBQ0csWUFBVCxFQUFQO0FBQ0Esc0JBQ0k7QUFBQSwyQkFDSTtBQUFBLGdCQUNLRDtBQURMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFRSCxDQVhEOztBQVlBLCtEQUFlSCxRQUFmIiwiZmlsZSI6Ii4vY29tcG9uZW50cy9EYXRlVGltZS9pbmRleC5qcy5qcyIsInNvdXJjZXNDb250ZW50IjpbInZhciBkYXRldGltZSA9ICgpID0+e1xuICAgIHZhciBzaG93ZGF0ZT1uZXcgRGF0ZSgpO1xuICAgIHZhciBkdD1zaG93ZGF0ZS50b0RhdGVTdHJpbmcoKTtcbiAgICByZXR1cm4oXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8c2NyZWVuTGVmdD5cbiAgICAgICAgICAgICAgICB7ZHR9XG4gICAgICAgICAgICA8L3NjcmVlbkxlZnQ+XG5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn1cbmV4cG9ydCBkZWZhdWx0IGRhdGV0aW1lIDsiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./components/DateTime/index.js\n");

/***/ }),

/***/ "./components/SearchBar/index.js":
/*!***************************************!*\
  !*** ./components/SearchBar/index.js ***!
  \***************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _Search_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Search.module.css */ \"./components/SearchBar/Search.module.css\");\n/* harmony import */ var _Search_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_Search_module_css__WEBPACK_IMPORTED_MODULE_1__);\n\nvar _jsxFileName = \"/Users/jasothomas/Documents/Projects/SA-2.0/JT-nextbeststock/components/SearchBar/index.js\";\n\nfunction ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }\n\nfunction _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }\n\nfunction _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }\n\n\n\nconst SearchBar = (_ref) => {\n  let rest = Object.assign({}, _ref);\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n    className: (_Search_module_css__WEBPACK_IMPORTED_MODULE_1___default().coin_search),\n    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", _objectSpread({\n      className: (_Search_module_css__WEBPACK_IMPORTED_MODULE_1___default().coin_input)\n    }, rest), void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 7,\n      columnNumber: 13\n    }, undefined)\n  }, void 0, false, {\n    fileName: _jsxFileName,\n    lineNumber: 6,\n    columnNumber: 9\n  }, undefined);\n};\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (SearchBar); // change coin to stock//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0YmVzdHN0b2NrLy4vY29tcG9uZW50cy9TZWFyY2hCYXIvaW5kZXguanM/MTE4YiJdLCJuYW1lcyI6WyJTZWFyY2hCYXIiLCJyZXN0Iiwic3R5bGVzIiwiY29pbl9pbnB1dCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7QUFBQTs7QUFFQSxNQUFNQSxTQUFTLEdBQUcsVUFBZTtBQUFBLE1BQVZDLElBQVU7QUFDN0Isc0JBRUk7QUFBSyxhQUFTLEVBQUdDLHVFQUFqQjtBQUFBLDJCQUNJO0FBQU8sZUFBUyxFQUFFQSxzRUFBaUJDO0FBQW5DLE9BQXdDRixJQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUZKO0FBT0gsQ0FSRDs7QUFVQSwrREFBZUQsU0FBZixFLENBRUEiLCJmaWxlIjoiLi9jb21wb25lbnRzL1NlYXJjaEJhci9pbmRleC5qcy5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZXMgZnJvbSAnLi9TZWFyY2gubW9kdWxlLmNzcycgO1xuXG5jb25zdCBTZWFyY2hCYXIgPSAoey4uLnJlc3R9KSA9PiB7XG4gICAgcmV0dXJuKFxuICAgICAgICBcbiAgICAgICAgPGRpdiBjbGFzc05hbWUgPXtzdHlsZXMuY29pbl9zZWFyY2h9PlxuICAgICAgICAgICAgPGlucHV0IGNsYXNzTmFtZT17c3R5bGVzLmNvaW5faW5wdXR9ey4uLnJlc3R9Lz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIFxuICAgICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBTZWFyY2hCYXI7XG5cbi8vIGNoYW5nZSBjb2luIHRvIHN0b2NrICJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./components/SearchBar/index.js\n");

/***/ }),

/***/ "./components/StockList.js":
/*!*********************************!*\
  !*** ./components/StockList.js ***!
  \*********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": function() { return /* binding */ StockList; }\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _Stocks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Stocks */ \"./components/Stocks/index.js\");\n\n\nvar _jsxFileName = \"/Users/jasothomas/Documents/Projects/SA-2.0/JT-nextbeststock/components/StockList.js\";\n\nfunction StockList({\n  filteredCoin\n}) {\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n    children: filteredCoin.map(stock => {\n      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Stocks__WEBPACK_IMPORTED_MODULE_1__.default, {\n        name: stock.Name,\n        symbol: stock.Symbol,\n        price: stock.Close,\n        open: stock.Open,\n        close: stock.Close,\n        high: stock.High,\n        low: stock.Low,\n        marketcap: stock.Marketcap,\n        volume: stock.Volume,\n        pe: stock.PE,\n        logo: stock.Logo\n      }, stock.Symbol, false, {\n        fileName: _jsxFileName,\n        lineNumber: 8,\n        columnNumber: 11\n      }, this);\n    })\n  }, void 0, false);\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0YmVzdHN0b2NrLy4vY29tcG9uZW50cy9TdG9ja0xpc3QuanM/MGUyNyJdLCJuYW1lcyI6WyJTdG9ja0xpc3QiLCJmaWx0ZXJlZENvaW4iLCJtYXAiLCJzdG9jayIsIk5hbWUiLCJTeW1ib2wiLCJDbG9zZSIsIk9wZW4iLCJIaWdoIiwiTG93IiwiTWFya2V0Y2FwIiwiVm9sdW1lIiwiUEUiLCJMb2dvIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUE7QUFFZSxTQUFTQSxTQUFULENBQW1CO0FBQUVDO0FBQUYsQ0FBbkIsRUFBcUM7QUFDbEQsc0JBQ0U7QUFBQSxjQUNHQSxZQUFZLENBQUNDLEdBQWIsQ0FBaUJDLEtBQUssSUFBSTtBQUN6QiwwQkFDRSw4REFBQyw0Q0FBRDtBQUVBLFlBQUksRUFBSUEsS0FBSyxDQUFDQyxJQUZkO0FBR0EsY0FBTSxFQUFJRCxLQUFLLENBQUNFLE1BSGhCO0FBSUEsYUFBSyxFQUFJRixLQUFLLENBQUNHLEtBSmY7QUFLQSxZQUFJLEVBQUlILEtBQUssQ0FBQ0ksSUFMZDtBQU1BLGFBQUssRUFBSUosS0FBSyxDQUFDRyxLQU5mO0FBT0EsWUFBSSxFQUFJSCxLQUFLLENBQUNLLElBUGQ7QUFRQSxXQUFHLEVBQUlMLEtBQUssQ0FBQ00sR0FSYjtBQVNBLGlCQUFTLEVBQUlOLEtBQUssQ0FBQ08sU0FUbkI7QUFVQSxjQUFNLEVBQUlQLEtBQUssQ0FBQ1EsTUFWaEI7QUFXQSxVQUFFLEVBQUlSLEtBQUssQ0FBQ1MsRUFYWjtBQVlBLFlBQUksRUFBSVQsS0FBSyxDQUFDVTtBQVpkLFNBQ09WLEtBQUssQ0FBQ0UsTUFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREY7QUFnQkQsS0FqQkE7QUFESCxtQkFERjtBQXNCRCIsImZpbGUiOiIuL2NvbXBvbmVudHMvU3RvY2tMaXN0LmpzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFN0b2NrcyBmcm9tICcuL1N0b2Nrcyc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFN0b2NrTGlzdCh7IGZpbHRlcmVkQ29pbiB9KSB7XG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIHtmaWx0ZXJlZENvaW4ubWFwKHN0b2NrID0+IHtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICA8U3RvY2tzXG4gICAgICAgICAga2V5ID0ge3N0b2NrLlN5bWJvbH1cbiAgICAgICAgICBuYW1lID0ge3N0b2NrLk5hbWV9XG4gICAgICAgICAgc3ltYm9sID0ge3N0b2NrLlN5bWJvbH1cbiAgICAgICAgICBwcmljZSA9IHtzdG9jay5DbG9zZX1cbiAgICAgICAgICBvcGVuID0ge3N0b2NrLk9wZW59XG4gICAgICAgICAgY2xvc2UgPSB7c3RvY2suQ2xvc2V9XG4gICAgICAgICAgaGlnaCA9IHtzdG9jay5IaWdofVxuICAgICAgICAgIGxvdyA9IHtzdG9jay5Mb3d9XG4gICAgICAgICAgbWFya2V0Y2FwID0ge3N0b2NrLk1hcmtldGNhcH1cbiAgICAgICAgICB2b2x1bWUgPSB7c3RvY2suVm9sdW1lfVxuICAgICAgICAgIHBlID0ge3N0b2NrLlBFfVxuICAgICAgICAgIGxvZ28gPSB7c3RvY2suTG9nb31cbiAgICAgICAgICAvPlxuICAgICAgICApO1xuICAgICAgfSl9XG4gICAgPC8+XG4gICk7XG59Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/StockList.js\n");

/***/ }),

/***/ "./components/Stocks/index.js":
/*!************************************!*\
  !*** ./components/Stocks/index.js ***!
  \************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _Stocks_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Stocks.module.css */ \"./components/Stocks/Stocks.module.css\");\n/* harmony import */ var _Stocks_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_Stocks_module_css__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ \"./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);\n\nvar _jsxFileName = \"/Users/jasothomas/Documents/Projects/SA-2.0/JT-nextbeststock/components/Stocks/index.js\";\n\n\n\nconst Stock = ({\n  name,\n  symbol,\n  price,\n  open,\n  close,\n  high,\n  low,\n  marketcap,\n  volume,\n  pe,\n  logo\n}) => {\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n    href: \"/ticker/[symbol]\",\n    as: `/ticker/${symbol}`,\n    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"a\", {\n      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: (_Stocks_module_css__WEBPACK_IMPORTED_MODULE_2___default().stock_container),\n        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n          className: (_Stocks_module_css__WEBPACK_IMPORTED_MODULE_2___default().stock_row),\n          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n            className: (_Stocks_module_css__WEBPACK_IMPORTED_MODULE_2___default().stock),\n            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"img\", {\n              src: logo,\n              alt: symbol,\n              className: (_Stocks_module_css__WEBPACK_IMPORTED_MODULE_2___default().stock_img)\n            }, void 0, false, {\n              fileName: _jsxFileName,\n              lineNumber: 23,\n              columnNumber: 21\n            }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h1\", {\n              className: (_Stocks_module_css__WEBPACK_IMPORTED_MODULE_2___default().stock_h1),\n              children: name\n            }, void 0, false, {\n              fileName: _jsxFileName,\n              lineNumber: 25,\n              columnNumber: 21\n            }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n              className: (_Stocks_module_css__WEBPACK_IMPORTED_MODULE_2___default().stock_symbol),\n              children: symbol\n            }, void 0, false, {\n              fileName: _jsxFileName,\n              lineNumber: 26,\n              columnNumber: 21\n            }, undefined)]\n          }, void 0, true, {\n            fileName: _jsxFileName,\n            lineNumber: 22,\n            columnNumber: 17\n          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n            className: (_Stocks_module_css__WEBPACK_IMPORTED_MODULE_2___default().stock_simple_data),\n            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n              className: (_Stocks_module_css__WEBPACK_IMPORTED_MODULE_2___default().stock_price),\n              children: [\"$\", price]\n            }, void 0, true, {\n              fileName: _jsxFileName,\n              lineNumber: 29,\n              columnNumber: 21\n            }, undefined)\n          }, void 0, false, {\n            fileName: _jsxFileName,\n            lineNumber: 28,\n            columnNumber: 17\n          }, undefined)]\n        }, void 0, true, {\n          fileName: _jsxFileName,\n          lineNumber: 21,\n          columnNumber: 13\n        }, undefined)\n      }, void 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 20,\n        columnNumber: 9\n      }, undefined)\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 19,\n      columnNumber: 13\n    }, undefined)\n  }, void 0, false, {\n    fileName: _jsxFileName,\n    lineNumber: 18,\n    columnNumber: 9\n  }, undefined);\n};\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (Stock); // stock button detail//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0YmVzdHN0b2NrLy4vY29tcG9uZW50cy9TdG9ja3MvaW5kZXguanM/N2NlMyJdLCJuYW1lcyI6WyJTdG9jayIsIm5hbWUiLCJzeW1ib2wiLCJwcmljZSIsIm9wZW4iLCJjbG9zZSIsImhpZ2giLCJsb3ciLCJtYXJrZXRjYXAiLCJ2b2x1bWUiLCJwZSIsImxvZ28iLCJzdHlsZXMiLCJzdG9ja19pbWciXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUVBO0FBQ0E7O0FBRUEsTUFBTUEsS0FBSyxHQUFHLENBQUM7QUFBQ0MsTUFBRDtBQUNYQyxRQURXO0FBRVhDLE9BRlc7QUFHWEMsTUFIVztBQUlYQyxPQUpXO0FBS1hDLE1BTFc7QUFNWEMsS0FOVztBQU9YQyxXQVBXO0FBUVhDLFFBUlc7QUFTWEMsSUFUVztBQVVYQztBQVZXLENBQUQsS0FVQTtBQUNWLHNCQUNJLDhEQUFDLGtEQUFEO0FBQU0sUUFBSSxFQUFDLGtCQUFYO0FBQThCLE1BQUUsRUFBSyxXQUFVVCxNQUFPLEVBQXREO0FBQUEsMkJBQ0k7QUFBQSw2QkFDSjtBQUFLLGlCQUFTLEVBQUVVLDJFQUFoQjtBQUFBLCtCQUNJO0FBQUssbUJBQVMsRUFBRUEscUVBQWhCO0FBQUEsa0NBQ0k7QUFBSyxxQkFBUyxFQUFFQSxpRUFBaEI7QUFBQSxvQ0FDSTtBQUFLLGlCQUFHLEVBQUVELElBQVY7QUFBZ0IsaUJBQUcsRUFBR1QsTUFBdEI7QUFDQSx1QkFBUyxFQUFFVSxxRUFBZ0JDO0FBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREosZUFHSTtBQUFJLHVCQUFTLEVBQUVELG9FQUFmO0FBQUEsd0JBQWlDWDtBQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUhKLGVBSUk7QUFBRyx1QkFBUyxFQUFFVyx3RUFBZDtBQUFBLHdCQUFvQ1Y7QUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREosZUFPSTtBQUFLLHFCQUFTLEVBQUVVLDZFQUFoQjtBQUFBLG1DQUNJO0FBQUcsdUJBQVMsRUFBRUEsdUVBQWQ7QUFBQSw4QkFBb0NULEtBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFtQkgsQ0E5QkQ7O0FBZ0NBLCtEQUFlSCxLQUFmLEUsQ0FDQSIsImZpbGUiOiIuL2NvbXBvbmVudHMvU3RvY2tzL2luZGV4LmpzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXG5cbmltcG9ydCBzdHlsZXMgZnJvbSAnLi9TdG9ja3MubW9kdWxlLmNzcydcbmltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluaydcblxuY29uc3QgU3RvY2sgPSAoe25hbWUsXG4gICAgc3ltYm9sLFxuICAgIHByaWNlLFxuICAgIG9wZW4sXG4gICAgY2xvc2UsXG4gICAgaGlnaCxcbiAgICBsb3csXG4gICAgbWFya2V0Y2FwLFxuICAgIHZvbHVtZSxcbiAgICBwZSxcbiAgICBsb2dvfSkgPT4ge1xuICAgIHJldHVybiAoXG4gICAgICAgIDxMaW5rIGhyZWY9Jy90aWNrZXIvW3N5bWJvbF0nIGFzID0ge2AvdGlja2VyLyR7c3ltYm9sfWB9PlxuICAgICAgICAgICAgPGE+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuc3RvY2tfY29udGFpbmVyfT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuc3RvY2tfcm93fT5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLnN0b2NrfT5cbiAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e2xvZ299IGFsdCA9e3N5bWJvbH1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtzdHlsZXMuc3RvY2tfaW1nfS8+XG4gICAgICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9e3N0eWxlcy5zdG9ja19oMX0+e25hbWV9PC9oMT5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPXtzdHlsZXMuc3RvY2tfc3ltYm9sfT57c3ltYm9sfTwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLnN0b2NrX3NpbXBsZV9kYXRhfT5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPXtzdHlsZXMuc3RvY2tfcHJpY2V9PiR7cHJpY2V9PC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8L2E+XG4gICAgICAgIDwvTGluaz5cbiAgICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgU3RvY2tcbi8vIHN0b2NrIGJ1dHRvbiBkZXRhaWwgIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/Stocks/index.js\n");

/***/ }),

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": function() { return /* binding */ Home; },\n/* harmony export */   \"getServerSideProps\": function() { return /* binding */ getServerSideProps; }\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _components_SearchBar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/SearchBar */ \"./components/SearchBar/index.js\");\n/* harmony import */ var _components_StockList__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/StockList */ \"./components/StockList.js\");\n/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/Layout */ \"./components/Layout.js\");\n/* harmony import */ var _components_DateTime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/DateTime */ \"./components/DateTime/index.js\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);\n\nvar _jsxFileName = \"/Users/jasothomas/Documents/Projects/SA-2.0/JT-nextbeststock/pages/index.js\";\n\n\n\n\n\nfunction Home({\n  filteredCoin\n}) {\n  const {\n    0: search,\n    1: setSearch\n  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)('');\n  const allStocks = filteredCoin.filter(stock => stock.Name.toLowerCase().includes(search.toLowerCase()));\n\n  const handleChange = e => {\n    e.preventDefault();\n    setSearch(e.target.value.toLowerCase());\n  };\n\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_Layout__WEBPACK_IMPORTED_MODULE_3__.default, {\n    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n      className: \"stock_app\",\n      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_DateTime__WEBPACK_IMPORTED_MODULE_4__.default, {}, void 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 27,\n        columnNumber: 8\n      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_SearchBar__WEBPACK_IMPORTED_MODULE_1__.default, {\n        type: \"text\",\n        placeholder: \"Search\",\n        onChange: handleChange\n      }, void 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 28,\n        columnNumber: 8\n      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_StockList__WEBPACK_IMPORTED_MODULE_2__.default, {\n        filteredCoin: allStocks\n      }, void 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 30,\n        columnNumber: 8\n      }, this)]\n    }, void 0, true, {\n      fileName: _jsxFileName,\n      lineNumber: 25,\n      columnNumber: 6\n    }, this)\n  }, void 0, false, {\n    fileName: _jsxFileName,\n    lineNumber: 23,\n    columnNumber: 5\n  }, this);\n}\nconst getServerSideProps = async () => {\n  const res = await fetch('http://127.0.0.1:5000/stocks');\n  const filteredCoin = await res.json();\n  return {\n    props: {\n      filteredCoin\n    }\n  };\n}; //'https://api.stockgecko.com/api/v3/stocks/markets?vs_currency=usd&order=market_cap_desc&per_page=3&page=1&sparkline=false'//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0YmVzdHN0b2NrLy4vcGFnZXMvaW5kZXguanM/NDRkOCJdLCJuYW1lcyI6WyJIb21lIiwiZmlsdGVyZWRDb2luIiwic2VhcmNoIiwic2V0U2VhcmNoIiwidXNlU3RhdGUiLCJhbGxTdG9ja3MiLCJmaWx0ZXIiLCJzdG9jayIsIk5hbWUiLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwiaGFuZGxlQ2hhbmdlIiwiZSIsInByZXZlbnREZWZhdWx0IiwidGFyZ2V0IiwidmFsdWUiLCJnZXRTZXJ2ZXJTaWRlUHJvcHMiLCJyZXMiLCJmZXRjaCIsImpzb24iLCJwcm9wcyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUdlLFNBQVNBLElBQVQsQ0FBYztBQUFDQztBQUFELENBQWQsRUFBOEI7QUFFM0MsUUFBTTtBQUFBLE9BQUNDLE1BQUQ7QUFBQSxPQUFRQztBQUFSLE1BQXFCQywrQ0FBUSxDQUFDLEVBQUQsQ0FBbkM7QUFFQSxRQUFNQyxTQUFTLEdBQUdKLFlBQVksQ0FBQ0ssTUFBYixDQUFvQkMsS0FBSyxJQUN6Q0EsS0FBSyxDQUFDQyxJQUFOLENBQVdDLFdBQVgsR0FBeUJDLFFBQXpCLENBQWtDUixNQUFNLENBQUNPLFdBQVAsRUFBbEMsQ0FEZ0IsQ0FBbEI7O0FBR0UsUUFBTUUsWUFBWSxHQUFHQyxDQUFDLElBQUk7QUFDeEJBLEtBQUMsQ0FBQ0MsY0FBRjtBQUNBVixhQUFTLENBQUNTLENBQUMsQ0FBQ0UsTUFBRixDQUFTQyxLQUFULENBQWVOLFdBQWYsRUFBRCxDQUFUO0FBQ0QsR0FIRDs7QUFLRixzQkFFRSw4REFBQyx1REFBRDtBQUFBLDJCQUVDO0FBQUssZUFBUyxFQUFHLFdBQWpCO0FBQUEsOEJBRUUsOERBQUMseURBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGLGVBR0UsOERBQUMsMERBQUQ7QUFBVyxZQUFJLEVBQUcsTUFBbEI7QUFBd0IsbUJBQVcsRUFBQyxRQUFwQztBQUE2QyxnQkFBUSxFQUFJRTtBQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSEYsZUFLRSw4REFBQywwREFBRDtBQUFXLG9CQUFZLEVBQUVOO0FBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFGRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRkY7QUFlRDtBQUVNLE1BQU1XLGtCQUFrQixHQUFHLFlBQVc7QUFDM0MsUUFBTUMsR0FBRyxHQUFHLE1BQU1DLEtBQUssQ0FBQyw4QkFBRCxDQUF2QjtBQUVBLFFBQU1qQixZQUFZLEdBQUcsTUFBTWdCLEdBQUcsQ0FBQ0UsSUFBSixFQUEzQjtBQUNBLFNBQU07QUFDSkMsU0FBSyxFQUFDO0FBQ0puQjtBQURJO0FBREYsR0FBTjtBQUtELENBVE0sQyxDQVdOIiwiZmlsZSI6Ii4vcGFnZXMvaW5kZXguanMuanMiLCJzb3VyY2VzQ29udGVudCI6WyJcbmltcG9ydCBTZWFyY2hCYXIgZnJvbSAnLi4vY29tcG9uZW50cy9TZWFyY2hCYXInXG5pbXBvcnQgU3RvY2tMaXN0IGZyb20gJy4uL2NvbXBvbmVudHMvU3RvY2tMaXN0JztcbmltcG9ydCBMYXlvdXQgZnJvbSAnLi4vY29tcG9uZW50cy9MYXlvdXQnXG5pbXBvcnQgRGF0ZVRpbWUgZnJvbSAnLi4vY29tcG9uZW50cy9EYXRlVGltZSdcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhvbWUoe2ZpbHRlcmVkQ29pbn0pIHtcbiAgXG4gIGNvbnN0IFtzZWFyY2gsc2V0U2VhcmNoXSA9IHVzZVN0YXRlKCcnKVxuICBcbiAgY29uc3QgYWxsU3RvY2tzID0gZmlsdGVyZWRDb2luLmZpbHRlcihzdG9jayA9PlxuICAgIHN0b2NrLk5hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2gudG9Mb3dlckNhc2UoKSlcbiAgICApXG4gICAgY29uc3QgaGFuZGxlQ2hhbmdlID0gZSA9PiB7XG4gICAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICAgIHNldFNlYXJjaChlLnRhcmdldC52YWx1ZS50b0xvd2VyQ2FzZSgpKVxuICAgIH1cbiAgXG4gIHJldHVybiAoXG4gICAgXG4gICAgPExheW91dD4gICBcbiAgICAgXG4gICAgIDxkaXYgY2xhc3NOYW1lID0gJ3N0b2NrX2FwcCc+XG5cbiAgICAgICA8RGF0ZVRpbWUvPlxuICAgICAgIDxTZWFyY2hCYXIgdHlwZSA9ICd0ZXh0J3BsYWNlaG9sZGVyPSdTZWFyY2gnIG9uQ2hhbmdlID0ge2hhbmRsZUNoYW5nZX0vPlxuICAgICAgIFxuICAgICAgIDxTdG9ja0xpc3QgZmlsdGVyZWRDb2luPXthbGxTdG9ja3N9Lz5cbiAgICAgXG4gICAgIDwvZGl2PlxuICAgIFxuICAgIDwvTGF5b3V0PlxuICApO1xufVxuXG5leHBvcnQgY29uc3QgZ2V0U2VydmVyU2lkZVByb3BzID0gYXN5bmMoKSA9PiB7XG4gIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKCdodHRwOi8vMTI3LjAuMC4xOjUwMDAvc3RvY2tzJyk7XG5cbiAgY29uc3QgZmlsdGVyZWRDb2luID0gYXdhaXQgcmVzLmpzb24oKTtcbiAgcmV0dXJue1xuICAgIHByb3BzOntcbiAgICAgIGZpbHRlcmVkQ29pblxuICAgIH1cbiAgfTtcbn07XG5cbiAvLydodHRwczovL2FwaS5zdG9ja2dlY2tvLmNvbS9hcGkvdjMvc3RvY2tzL21hcmtldHM/dnNfY3VycmVuY3k9dXNkJm9yZGVyPW1hcmtldF9jYXBfZGVzYyZwZXJfcGFnZT0zJnBhZ2U9MSZzcGFya2xpbmU9ZmFsc2UnIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/index.js\n");

/***/ }),

/***/ "./components/SearchBar/Search.module.css":
/*!************************************************!*\
  !*** ./components/SearchBar/Search.module.css ***!
  \************************************************/
/***/ (function(module) {

eval("// Exports\nmodule.exports = {\n\t\"coin_search\": \"Search_coin_search__1iKT5\",\n\t\"coin_input\": \"Search_coin_input__1cvJm\"\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0YmVzdHN0b2NrLy4vY29tcG9uZW50cy9TZWFyY2hCYXIvU2VhcmNoLm1vZHVsZS5jc3M/OTYyOCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwiZmlsZSI6Ii4vY29tcG9uZW50cy9TZWFyY2hCYXIvU2VhcmNoLm1vZHVsZS5jc3MuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBFeHBvcnRzXG5tb2R1bGUuZXhwb3J0cyA9IHtcblx0XCJjb2luX3NlYXJjaFwiOiBcIlNlYXJjaF9jb2luX3NlYXJjaF9fMWlLVDVcIixcblx0XCJjb2luX2lucHV0XCI6IFwiU2VhcmNoX2NvaW5faW5wdXRfXzFjdkptXCJcbn07XG4iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./components/SearchBar/Search.module.css\n");

/***/ }),

/***/ "./components/Stocks/Stocks.module.css":
/*!*********************************************!*\
  !*** ./components/Stocks/Stocks.module.css ***!
  \*********************************************/
/***/ (function(module) {

eval("// Exports\nmodule.exports = {\n\t\"stock_container\": \"Stocks_stock_container__1-Fao\",\n\t\"stock_row\": \"Stocks_stock_row__2Szx0\",\n\t\"stock\": \"Stocks_stock__iw2z-\",\n\t\"stock_symbol\": \"Stocks_stock_symbol__1FXaV\",\n\t\"stock_simple_data\": \"Stocks_stock_simple_data__1CEnt\",\n\t\"stock_price\": \"Stocks_stock_price__LL-tv\",\n\t\"stock_img\": \"Stocks_stock_img__2l_EJ\",\n\t\"stock_h1\": \"Stocks_stock_h1__O4v5i\"\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0YmVzdHN0b2NrLy4vY29tcG9uZW50cy9TdG9ja3MvU3RvY2tzLm1vZHVsZS5jc3M/MGI5MSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwiZmlsZSI6Ii4vY29tcG9uZW50cy9TdG9ja3MvU3RvY2tzLm1vZHVsZS5jc3MuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBFeHBvcnRzXG5tb2R1bGUuZXhwb3J0cyA9IHtcblx0XCJzdG9ja19jb250YWluZXJcIjogXCJTdG9ja3Nfc3RvY2tfY29udGFpbmVyX18xLUZhb1wiLFxuXHRcInN0b2NrX3Jvd1wiOiBcIlN0b2Nrc19zdG9ja19yb3dfXzJTengwXCIsXG5cdFwic3RvY2tcIjogXCJTdG9ja3Nfc3RvY2tfX2l3MnotXCIsXG5cdFwic3RvY2tfc3ltYm9sXCI6IFwiU3RvY2tzX3N0b2NrX3N5bWJvbF9fMUZYYVZcIixcblx0XCJzdG9ja19zaW1wbGVfZGF0YVwiOiBcIlN0b2Nrc19zdG9ja19zaW1wbGVfZGF0YV9fMUNFbnRcIixcblx0XCJzdG9ja19wcmljZVwiOiBcIlN0b2Nrc19zdG9ja19wcmljZV9fTEwtdHZcIixcblx0XCJzdG9ja19pbWdcIjogXCJTdG9ja3Nfc3RvY2tfaW1nX18ybF9FSlwiLFxuXHRcInN0b2NrX2gxXCI6IFwiU3RvY2tzX3N0b2NrX2gxX19PNHY1aVwiXG59O1xuIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/Stocks/Stocks.module.css\n");

/***/ }),

/***/ "../next-server/lib/router-context":
/*!**************************************************************!*\
  !*** external "next/dist/next-server/lib/router-context.js" ***!
  \**************************************************************/
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ "../next-server/lib/router/utils/get-asset-path-from-route":
/*!**************************************************************************************!*\
  !*** external "next/dist/next-server/lib/router/utils/get-asset-path-from-route.js" ***!
  \**************************************************************************************/
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ (function(module) {

"use strict";
module.exports = require("next/head");;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ "react-is":
/*!***************************!*\
  !*** external "react-is" ***!
  \***************************/
/***/ (function(module) {

"use strict";
module.exports = require("react-is");;

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ (function(module) {

"use strict";
module.exports = require("react/jsx-dev-runtime");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, ["vendors-node_modules_next_link_js","components_Layout_js"], function() { return __webpack_exec__("./pages/index.js"); });
module.exports = __webpack_exports__;

})();