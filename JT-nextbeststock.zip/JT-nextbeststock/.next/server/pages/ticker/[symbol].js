/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(function() {
var exports = {};
exports.id = "pages/ticker/[symbol]";
exports.ids = ["pages/ticker/[symbol]"];
exports.modules = {

/***/ "./pages/ticker/[symbol].js":
/*!**********************************!*\
  !*** ./pages/ticker/[symbol].js ***!
  \**********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"getServerSideProps\": function() { return /* binding */ getServerSideProps; }\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../components/Layout */ \"./components/Layout.js\");\n/* harmony import */ var _Symbol_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Symbol.module.css */ \"./pages/ticker/Symbol.module.css\");\n/* harmony import */ var _Symbol_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_Symbol_module_css__WEBPACK_IMPORTED_MODULE_2__);\n\nvar _jsxFileName = \"/Users/jasothomas/Documents/Projects/SA-2.0/JT-nextbeststock/pages/ticker/[symbol].js\";\n\n\n\nconst Stock = ({\n  stock\n}) => {\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_Layout__WEBPACK_IMPORTED_MODULE_1__.default, {\n    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n      className: (_Symbol_module_css__WEBPACK_IMPORTED_MODULE_2___default().stock_page),\n      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: (_Symbol_module_css__WEBPACK_IMPORTED_MODULE_2___default().stock_container)\n      }, void 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 8,\n        columnNumber: 9\n      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"img\", {\n        src: stock.Logo,\n        alt: stock.Name,\n        classname: (_Symbol_module_css__WEBPACK_IMPORTED_MODULE_2___default().stock_image)\n      }, void 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 9,\n        columnNumber: 9\n      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h1\", {\n        className: (_Symbol_module_css__WEBPACK_IMPORTED_MODULE_2___default().stock_name),\n        children: stock.Name\n      }, void 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 13,\n        columnNumber: 7\n      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n        className: (_Symbol_module_css__WEBPACK_IMPORTED_MODULE_2___default().stock_open),\n        children: [\"Open: $\", stock.Open]\n      }, void 0, true, {\n        fileName: _jsxFileName,\n        lineNumber: 14,\n        columnNumber: 7\n      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n        className: (_Symbol_module_css__WEBPACK_IMPORTED_MODULE_2___default().stock_close),\n        children: [\"Close: $\", stock.Close]\n      }, void 0, true, {\n        fileName: _jsxFileName,\n        lineNumber: 15,\n        columnNumber: 7\n      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n        className: (_Symbol_module_css__WEBPACK_IMPORTED_MODULE_2___default().stock_high),\n        children: [\"High: $\", stock.High]\n      }, void 0, true, {\n        fileName: _jsxFileName,\n        lineNumber: 16,\n        columnNumber: 7\n      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n        className: (_Symbol_module_css__WEBPACK_IMPORTED_MODULE_2___default().stock_low),\n        children: [\"Low: $\", stock.Low]\n      }, void 0, true, {\n        fileName: _jsxFileName,\n        lineNumber: 17,\n        columnNumber: 7\n      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n        className: (_Symbol_module_css__WEBPACK_IMPORTED_MODULE_2___default().stock_pe),\n        children: [\"P/E: $\", stock.PE]\n      }, void 0, true, {\n        fileName: _jsxFileName,\n        lineNumber: 18,\n        columnNumber: 7\n      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n        className: (_Symbol_module_css__WEBPACK_IMPORTED_MODULE_2___default().stock_volume),\n        children: [\"Volume: \", stock.Volume]\n      }, void 0, true, {\n        fileName: _jsxFileName,\n        lineNumber: 19,\n        columnNumber: 7\n      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n        className: (_Symbol_module_css__WEBPACK_IMPORTED_MODULE_2___default().stock_marketcap),\n        children: [\"Marketcap: \", stock.Marketcap]\n      }, void 0, true, {\n        fileName: _jsxFileName,\n        lineNumber: 20,\n        columnNumber: 7\n      }, undefined)]\n    }, void 0, true, {\n      fileName: _jsxFileName,\n      lineNumber: 7,\n      columnNumber: 7\n    }, undefined)\n  }, void 0, false, {\n    fileName: _jsxFileName,\n    lineNumber: 6,\n    columnNumber: 5\n  }, undefined);\n};\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (Stock);\nasync function getServerSideProps(context) {\n  const {\n    symbol\n  } = context.query;\n  const res = await fetch(`http://127.0.0.1:5000/${symbol}`);\n  const data = await res.json();\n  return {\n    props: {\n      stock: data\n    }\n  };\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0YmVzdHN0b2NrLy4vcGFnZXMvdGlja2VyL1tzeW1ib2xdLmpzPzk0ODgiXSwibmFtZXMiOlsiU3RvY2siLCJzdG9jayIsInN0eWxlcyIsInN0b2NrX2NvbnRhaW5lciIsIkxvZ28iLCJOYW1lIiwic3RvY2tfaW1hZ2UiLCJPcGVuIiwiQ2xvc2UiLCJIaWdoIiwiTG93IiwiUEUiLCJWb2x1bWUiLCJNYXJrZXRjYXAiLCJnZXRTZXJ2ZXJTaWRlUHJvcHMiLCJjb250ZXh0Iiwic3ltYm9sIiwicXVlcnkiLCJyZXMiLCJmZXRjaCIsImRhdGEiLCJqc29uIiwicHJvcHMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTs7QUFFQSxNQUFNQSxLQUFLLEdBQUcsQ0FBQztBQUFDQztBQUFELENBQUQsS0FBYTtBQUN6QixzQkFDRSw4REFBQyx1REFBRDtBQUFBLDJCQUNFO0FBQUssZUFBUyxFQUFJQyxzRUFBbEI7QUFBQSw4QkFDRTtBQUFLLGlCQUFTLEVBQUlBLDJFQUFzQkM7QUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQUVFO0FBQUssV0FBRyxFQUFJRixLQUFLLENBQUNHLElBQWxCO0FBQ0EsV0FBRyxFQUFFSCxLQUFLLENBQUNJLElBRFg7QUFFQSxpQkFBUyxFQUFJSCx1RUFBa0JJO0FBRi9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkYsZUFNQTtBQUFJLGlCQUFTLEVBQUVKLHNFQUFmO0FBQUEsa0JBQW1DRCxLQUFLLENBQUNJO0FBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTkEsZUFPQTtBQUFHLGlCQUFTLEVBQUVILHNFQUFkO0FBQUEsOEJBQXlDRCxLQUFLLENBQUNNLElBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFQQSxlQVFBO0FBQUcsaUJBQVMsRUFBRUwsdUVBQWQ7QUFBQSwrQkFBMkNELEtBQUssQ0FBQ08sS0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVJBLGVBU0E7QUFBRyxpQkFBUyxFQUFFTixzRUFBZDtBQUFBLDhCQUF5Q0QsS0FBSyxDQUFDUSxJQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVEEsZUFVQTtBQUFHLGlCQUFTLEVBQUVQLHFFQUFkO0FBQUEsNkJBQXVDRCxLQUFLLENBQUNTLEdBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFWQSxlQVdBO0FBQUcsaUJBQVMsRUFBRVIsb0VBQWQ7QUFBQSw2QkFBc0NELEtBQUssQ0FBQ1UsRUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVhBLGVBWUE7QUFBRyxpQkFBUyxFQUFFVCx3RUFBZDtBQUFBLCtCQUE0Q0QsS0FBSyxDQUFDVyxNQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWkEsZUFhQTtBQUFHLGlCQUFTLEVBQUVWLDJFQUFkO0FBQUEsa0NBQWtERCxLQUFLLENBQUNZLFNBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFiQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFvQkQsQ0FyQkQ7O0FBdUJBLCtEQUFlYixLQUFmO0FBRU8sZUFBZWMsa0JBQWYsQ0FBa0NDLE9BQWxDLEVBQTBDO0FBQy9DLFFBQU07QUFBQ0M7QUFBRCxNQUFXRCxPQUFPLENBQUNFLEtBQXpCO0FBQ0EsUUFBTUMsR0FBRyxHQUFHLE1BQU1DLEtBQUssQ0FBRyx5QkFBd0JILE1BQU8sRUFBbEMsQ0FBdkI7QUFFQSxRQUFNSSxJQUFJLEdBQUcsTUFBTUYsR0FBRyxDQUFDRyxJQUFKLEVBQW5CO0FBQ0EsU0FBTTtBQUNKQyxTQUFLLEVBQUM7QUFDSnJCLFdBQUssRUFBRW1CO0FBREg7QUFERixHQUFOO0FBS0QiLCJmaWxlIjoiLi9wYWdlcy90aWNrZXIvW3N5bWJvbF0uanMuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgTGF5b3V0IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvTGF5b3V0J1xuaW1wb3J0IHN0eWxlcyBmcm9tICcuL1N5bWJvbC5tb2R1bGUuY3NzJ1xuXG5jb25zdCBTdG9jayA9ICh7c3RvY2t9KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPExheW91dD5cbiAgICAgIDxkaXYgY2xhc3NOYW1lID0ge3N0eWxlcy5zdG9ja19wYWdlfT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWUgPSB7c3R5bGVzLnN0b2NrX2NvbnRhaW5lcn0+PC9kaXY+XG4gICAgICAgIDxpbWcgc3JjID0ge3N0b2NrLkxvZ299IFxuICAgICAgICBhbHQ9e3N0b2NrLk5hbWV9IFxuICAgICAgICBjbGFzc25hbWUgPSB7c3R5bGVzLnN0b2NrX2ltYWdlfVxuICAgICAgICAvPlxuICAgICAgPGgxIGNsYXNzTmFtZT17c3R5bGVzLnN0b2NrX25hbWV9PntzdG9jay5OYW1lfTwvaDE+XG4gICAgICA8cCBjbGFzc05hbWU9e3N0eWxlcy5zdG9ja19vcGVufT5PcGVuOiAke3N0b2NrLk9wZW59PC9wPlxuICAgICAgPHAgY2xhc3NOYW1lPXtzdHlsZXMuc3RvY2tfY2xvc2V9PkNsb3NlOiAke3N0b2NrLkNsb3NlfTwvcD5cbiAgICAgIDxwIGNsYXNzTmFtZT17c3R5bGVzLnN0b2NrX2hpZ2h9PkhpZ2g6ICR7c3RvY2suSGlnaH08L3A+XG4gICAgICA8cCBjbGFzc05hbWU9e3N0eWxlcy5zdG9ja19sb3d9PkxvdzogJHtzdG9jay5Mb3d9PC9wPlxuICAgICAgPHAgY2xhc3NOYW1lPXtzdHlsZXMuc3RvY2tfcGV9PlAvRTogJHtzdG9jay5QRX08L3A+XG4gICAgICA8cCBjbGFzc05hbWU9e3N0eWxlcy5zdG9ja192b2x1bWV9PlZvbHVtZToge3N0b2NrLlZvbHVtZX08L3A+XG4gICAgICA8cCBjbGFzc05hbWU9e3N0eWxlcy5zdG9ja19tYXJrZXRjYXB9Pk1hcmtldGNhcDoge3N0b2NrLk1hcmtldGNhcH08L3A+XG4gICAgICA8L2Rpdj5cbiAgICA8L0xheW91dD5cbiAgICBcbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBTdG9jayBcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcnZlclNpZGVQcm9wcyhjb250ZXh0KXtcbiAgY29uc3Qge3N5bWJvbH0gPSBjb250ZXh0LnF1ZXJ5IFxuICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCAoYGh0dHA6Ly8xMjcuMC4wLjE6NTAwMC8ke3N5bWJvbH1gKVxuXG4gIGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpXG4gIHJldHVybntcbiAgICBwcm9wczp7XG4gICAgICBzdG9jazogZGF0YVxuICAgIH1cbiAgfVxufVxuICBcbiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/ticker/[symbol].js\n");

/***/ }),

/***/ "./pages/ticker/Symbol.module.css":
/*!****************************************!*\
  !*** ./pages/ticker/Symbol.module.css ***!
  \****************************************/
/***/ (function(module) {

eval("// Exports\nmodule.exports = {\n\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0YmVzdHN0b2NrLy4vcGFnZXMvdGlja2VyL1N5bWJvbC5tb2R1bGUuY3NzP2U0ZWQiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTs7QUFFQSIsImZpbGUiOiIuL3BhZ2VzL3RpY2tlci9TeW1ib2wubW9kdWxlLmNzcy5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIEV4cG9ydHNcbm1vZHVsZS5leHBvcnRzID0ge1xuXG59O1xuIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/ticker/Symbol.module.css\n");

/***/ }),

/***/ "../next-server/lib/router-context":
/*!**************************************************************!*\
  !*** external "next/dist/next-server/lib/router-context.js" ***!
  \**************************************************************/
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ "../next-server/lib/router/utils/get-asset-path-from-route":
/*!**************************************************************************************!*\
  !*** external "next/dist/next-server/lib/router/utils/get-asset-path-from-route.js" ***!
  \**************************************************************************************/
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ (function(module) {

"use strict";
module.exports = require("next/head");;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ "react-is":
/*!***************************!*\
  !*** external "react-is" ***!
  \***************************/
/***/ (function(module) {

"use strict";
module.exports = require("react-is");;

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ (function(module) {

"use strict";
module.exports = require("react/jsx-dev-runtime");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, ["vendors-node_modules_next_link_js","components_Layout_js"], function() { return __webpack_exec__("./pages/ticker/[symbol].js"); });
module.exports = __webpack_exports__;

})();