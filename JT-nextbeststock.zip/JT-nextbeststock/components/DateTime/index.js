var datetime = () =>{
    var showdate=new Date();
    var dt=showdate.toDateString();
    return(
        <div>
            <screenLeft>
                {dt}
            </screenLeft>

        </div>
    );
}
export default datetime ;