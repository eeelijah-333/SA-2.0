
import SearchBar from '../components/SearchBar'
import StockList from '../components/StockList';
import Layout from '../components/Layout'
import DateTime from '../components/DateTime'
import { useState } from 'react';


export default function Home({filteredCoin}) {
  
  const [search,setSearch] = useState('')
  
  const allStocks = filteredCoin.filter(stock =>
    stock.Name.toLowerCase().includes(search.toLowerCase())
    )
    const handleChange = e => {
      e.preventDefault()
      setSearch(e.target.value.toLowerCase())
    }
  
  return (
    
    <Layout>   
     
     <div className = 'stock_app'>

       <DateTime/>
       <SearchBar type = 'text'placeholder='Search' onChange = {handleChange}/>
       
       <StockList filteredCoin={allStocks}/>
     
     </div>
    
    </Layout>
  );
}

export const getServerSideProps = async() => {
  const res = await fetch('http://127.0.0.1:5000/stocks');

  const filteredCoin = await res.json();
  return{
    props:{
      filteredCoin
    }
  };
};

 //'https://api.stockgecko.com/api/v3/stocks/markets?vs_currency=usd&order=market_cap_desc&per_page=3&page=1&sparkline=false'