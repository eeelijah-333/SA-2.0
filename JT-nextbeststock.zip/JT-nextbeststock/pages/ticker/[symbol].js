import Layout from '../../components/Layout'
import styles from './Symbol.module.css'

const Stock = ({stock}) => {
  return (
    <Layout>
      <div className = {styles.stock_page}>
        <div className = {styles.stock_container}></div>
        <img src = {stock.Logo} 
        alt={stock.Name} 
        classname = {styles.stock_image}
        />
      <h1 className={styles.stock_name}>{stock.Name}</h1>
      <p className={styles.stock_open}>Open: ${stock.Open}</p>
      <p className={styles.stock_close}>Close: ${stock.Close}</p>
      <p className={styles.stock_high}>High: ${stock.High}</p>
      <p className={styles.stock_low}>Low: ${stock.Low}</p>
      <p className={styles.stock_pe}>P/E: ${stock.PE}</p>
      <p className={styles.stock_volume}>Volume: {stock.Volume}</p>
      <p className={styles.stock_marketcap}>Marketcap: {stock.Marketcap}</p>
      </div>
    </Layout>
    
  )
}

export default Stock 

export async function getServerSideProps(context){
  const {symbol} = context.query 
  const res = await fetch (`http://127.0.0.1:5000/${symbol}`)

  const data = await res.json()
  return{
    props:{
      stock: data
    }
  }
}
  
